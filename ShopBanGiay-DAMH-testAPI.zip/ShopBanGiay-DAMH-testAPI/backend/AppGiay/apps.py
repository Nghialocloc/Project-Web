from django.apps import AppConfig


class AppgiayConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AppGiay'
